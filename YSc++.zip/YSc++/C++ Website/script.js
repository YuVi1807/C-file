function hello(url1, url2) {
    window.open(url1, 'center');
    window.open(url2, 'right');
}

function dc(url1, url2) {
    window.open(url1, 'center');
    window.open(url2, 'right');
}

function str(url1, url2) {
    window.open(url1, 'center');
    window.open(url2, 'right');
}

function bcp(url1, url2) {
    window.open(url1, 'center');
    window.open(url2, 'right');
}

function fun(url1, url2) {
    window.open(url1, 'center');
    window.open(url2, 'right');
}

function oop(url1, url2) {
    window.open(url1, 'center');
    window.open(url2, 'right');
}

function oover(url1, url2) {
    window.open(url1, 'center');
    window.open(url2, 'right');
}

function fh(url1, url2) {
    window.open(url1, 'center');
    window.open(url2, 'right');
}

function vf(url1, url2) {
    window.open(url1, 'center');
    window.open(url2, 'right');
}

function inh(url1, url2) {
    window.open(url1, 'center');
    window.open(url2, 'right');
}

function sd(url1, url2) {
    window.open(url1, 'center');
    window.open(url2, 'right');
}