#include <iostream>

using namespace std;

class Shape{
    public:
    virtual void getArea(){
        cout<<"PLEASE SPECIFY A SHAPE"<<endl;
    }
};

class Rectangle : public Shape{
    public:
    void getArea() override{
        int l,b;
        cout<<"ENTER DIMENSIONS : ";
        cin>>l>>b;
        cout<<"AREA OF RECTANGLE : "<<l*b<<endl;
    }
};

int main() {
    Shape s;
    Rectangle r;
    s.getArea();
    r.getArea();
    return 0;
}