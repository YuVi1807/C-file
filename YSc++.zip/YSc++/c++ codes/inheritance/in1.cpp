#include <iostream>

using namespace std;

class Animal{
    public:
    virtual void makeSound(){
        cout<<"ANIMAL MAKING SOUND"<<endl;
    }
};

class Cat : public Animal{
    public:
    void makeSound() override{
        cout<<"CAT MEOW"<<endl;
    }
};

int main() {
    Animal animal;
    Cat cat;
    animal.makeSound();
    cat.makeSound();
    return 0;
}