#include <iostream>

using namespace std;

class Employee{
    public:
    virtual void work(){
        cout<<"EMPLOYEE IS WORKING"<<endl;
    }
    void getSalary(){
        cout<<"YOU GOT YOUR SALARY !!!"<<endl;
    }
};

class HRManager : public Employee{
    void addEmployee(){
        cout<<"EMPLOYEE ADDED"<<endl;
    }
    public:
    void work() override{
        cout<<"HR MANAGER IS WORKING"<<endl;
        addEmployee();
    }
};

int main() {
    Employee e;
    HRManager h;
    e.work();
    e.getSalary();
    h.work();
    h.getSalary();
    return 0;
}