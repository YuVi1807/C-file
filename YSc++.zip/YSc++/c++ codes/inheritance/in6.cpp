#include <iostream>

using namespace std;

class Animal{
    public:
    virtual void move(){
        cout<<"ANIMAL MOVES"<<endl;
    }
};

class Cheetah : public Animal{
    public:
    void move() override{
        cout<<"CHEETAH MOVES"<<endl;
    }
};

int main() {
    Animal a;
    Cheetah c;
    a.move();
    c.move();
    return 0;
}