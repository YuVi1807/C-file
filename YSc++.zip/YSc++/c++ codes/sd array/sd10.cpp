#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
    int arr[8]={663,653,634,6354,5747,4755,245,465};

    int small=arr[0];
    for(int i=0; i<8; i++){
        if(arr[i]<small){
            small=arr[i];
        }
    }
    cout<<"The Smallest element of this array is: "<<small;
    return 0;
}

