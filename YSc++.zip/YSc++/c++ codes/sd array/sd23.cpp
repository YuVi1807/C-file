#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
    int arr[]={1,2,3,4,5,6,7,8};
    int size= sizeof(arr)/sizeof(arr[0]);

    cout<<"Elements of array before swapping the first and last element: "<<endl;
    for(int i=0; i<size; i++){
        cout<<arr[i]<<'\t';
    }
    cout<<endl;
        int temp=arr[0];
        arr[0]=arr[7];
        arr[7]=temp;
    cout<<"Elements of array after swapping the first and last element: "<<endl;
    for(int i=0; i<size; i++){
        cout<<arr[i]<<'\t';
    }
    return 0;
}
