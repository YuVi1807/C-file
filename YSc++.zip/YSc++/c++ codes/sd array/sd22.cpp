#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
    int n;
    cout<<"Enter size of the array: ";
    cin>>n;
    int arr[n];

    cout<<"Enter elements for array: ";
    for(int i=0; i<n; i++){
        cin>>arr[i];
    }

    cout<<"Odd Numbers of this array is: ";
    for(int i=0; i<n; i++){
        if(arr[i]%2!=0){
           cout<<arr[i]<<'\t';
        }
    }
    cout<<endl;
     cout<<"Even Numbers of this array is: ";
      for(int i=0; i<n; i++){
        if(arr[i]%2==0){
           cout<<arr[i]<<'\t';
        }
    }
    return 0;
}
