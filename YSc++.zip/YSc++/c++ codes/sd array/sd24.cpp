#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
    int odd=0, even=odd;
    int arr[]={1,2,3,4,5,6,7,8};
    int size= sizeof(arr)/sizeof(arr[0]);

     for(int i=0; i<size; i++){
        if(arr[i]%2!=0){
           odd+=1;
        }
    }
    for(int i=0; i<size; i++){
        if(arr[i]%2==0){
           even+=1;
        }
    }

    cout<<"Odd numbers in this array is: "<<odd;
    cout<<endl;
    cout<<"Even numbers in this array is: "<<even;
    return 0;
}    