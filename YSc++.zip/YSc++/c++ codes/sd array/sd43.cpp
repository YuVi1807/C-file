#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
  int ar[]={5,53,1,2,25,15,26,10};
  int n;
  cout<<"Array : "<<endl;
  int l=sizeof(ar)/sizeof(int);
  for(int i=0;i<l;i++){
    cout<<ar[i]<<" ";  
  }

  cout<<endl<<"Enter the element you want to check in array : ";
  cin>>n;

  int i;

  for(i=0;i<l;i++){
     if(ar[i]==n){
       cout<<"Key Element found in this array at index "<<i;
       break;
     }
  }
  if(i==l){
  cout<<"Key Element not found in this array ";
  } 

  return 0;
  }
