#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
    int arr[]={35,336,536,236,26,32,26,6324,23,3466,362};

    int size= sizeof(arr)/sizeof(arr[0]);
    int count= 0;

    for(int i=0; i<size; i++){
        count+=1;
    }
    cout<<"The number of elements present in this array is: "<<count;
    return 0;
}
