#include<iostream>
#include<conio.h>

using namespace std;

int common(int ar[],int n,int s);

int main()
{
  int ar1[]={6,2,36,10,23,13,46,31};
  int ar2[]={4,5,3,2,1,10,13,6,14};

  int l1=sizeof(ar1)/sizeof(int);
  int l2=sizeof(ar2)/sizeof(int);
  cout<<"Array 1 : "<<endl;
  for(int i=0;i<l1;i++){
    cout<<ar1[i]<<" ";  
  }
  cout<<endl<<"Array 2 : "<<endl;
  for(int i=0;i<l2;i++){
    cout<<ar2[i]<<" ";  
  }

  int ca[10],cai=0;
  for(int i=0;i<l1;i++){
     for(int j=0;j<l2;j++){
           if(ar1[i]==ar2[j]){
               if(common(ca,ar1[i],cai)){
                  ca[cai]=ar1[i];
                  cai++;  
              }
             }
           }} 
  cout<<endl<<"Common elements between arrays : "<<endl;
  for(int i=0;i<cai;i++){
    cout<<ca[i]<<" ";  
  }
  return 0;
}

int common(int ar[],int n,int s){
    for(int i=0;i<s;i++){
       if(ar[i]==n){
         return 0;
       }
    }
    return 1;
}
