#include<iostream>
#include<conio.h>

using namespace std;

void reverseinteger(int Array[], int n);
void printinteger(int Array[], int n);

int main()
{
    int arr[]={1,2,3,4,5};
    cout<<"Elements of array before reverse: "<<endl;
    for(int i=0; i<5; i++){
        cout<<arr[i]<<'\t';
    }
    cout<<endl;
    cout<<"Elements of array after reverse: "<<endl; 
    reverseinteger(arr,5);
    printinteger(arr,5);
    return 0;
}

void printinteger(int Array[], int n){
    for(int i=0; i<5; i++){
        cout<<Array[i]<<'\t';
    }
}

void reverseinteger(int Array[], int n){
    for(int i=0; i<n/2; i++){
    int firstvalue= Array[i];
    int secondvalue= Array[5-i-1];
    Array[i]= secondvalue;
    Array[5-i-1]= firstvalue;
    }
}