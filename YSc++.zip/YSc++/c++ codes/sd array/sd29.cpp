#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
  int ar[]={632,236,315,345,584,685,345,15};
  int max=ar[0],min=ar[0];

  cout<<"Array : "<<endl;
  int l=sizeof(ar)/sizeof(int);
  for(int i=0;i<l;i++){
    cout<<ar[i]<<" ";  
  }

  for(int i=0;i<l;i++){
    if(max<ar[i]){
      max=ar[i];
    }
    else if(min>ar[i]){
      min=ar[i];
    }
  }

  cout<<endl<<"Maximum value of array : "<<max<<endl;
  cout<<"Minimum value of array : "<<min;
  return 0;
  }
