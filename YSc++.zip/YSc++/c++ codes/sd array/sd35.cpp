#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
    int arr[8]={1,2,3,4,5,6,7,8};
    int small=arr[0];

    for(int i=0; i<8; i++){
        if(arr[i]<small){
            small=arr[i];
        }
    }
    cout<<"The 2nd Lowest number of this array is: "<<small+1;
    return 0;
}
