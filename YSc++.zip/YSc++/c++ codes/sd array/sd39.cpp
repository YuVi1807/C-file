#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
  int arr[10],n;

  cout<<"Enter the no. of elements of array: ";
  cin>>n;

  cout<<"Enter the elements of arrays : "; 
  for(int i=0;i<n;i++){
    cin>>arr[i];
  }

  int t=arr[n-1];
  for(int i=n-1;i>0;i--){
    arr[i]=arr[i-1];
  }

    arr[0]=t;

  cout<<"Elements of array after  rotating ones clockwise : "<<endl;
  for(int i=0;i<n;i++){
    cout<<arr[i]<<"  ";
  }
  
  return 0;
  }
