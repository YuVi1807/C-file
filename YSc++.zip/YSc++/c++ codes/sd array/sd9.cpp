#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
    int arr[8]={1,4,4,13,15,1,23,1};

    int large= arr[0];
    for(int i=0; i<8; i++){
        if(arr[i]>large){
            large=arr[i];
        }
    }
    cout<<"The largest element of this array is: "<<large;
    return 0;   
}
