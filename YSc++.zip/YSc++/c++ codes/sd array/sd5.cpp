#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
    int n;
    cout<<"Enter size of the array: ";
    cin>>n;
    int array[n];

    cout<<"Enter elements for array: ";
    for(int i=0; i<n; i++){
        cin>>array[i];
    }

    cout<<"Elements of array is: ";
     for(int i=0; i<n; i++){
        cout<<array[i]<<'\t';
    }

    return 0;
}