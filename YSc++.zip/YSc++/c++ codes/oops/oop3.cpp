#include<iostream>
#include<conio.h>

using namespace std;

class Rectangle
{
private:
    int width;
    int height;
public:
   void calculatetheareaandperimeter();
   void displaytheareaandperimeter();
};

void Rectangle:: calculatetheareaandperimeter(){
    cout<<"Enter Width of Rectangle: ";
    cin>>width;
    cout<<"Enter Height of Rectangle: ";
    cin>>height;
}

void Rectangle:: displaytheareaandperimeter(){
    calculatetheareaandperimeter();
    cout<<"The area of the rectangle is: "<<width*height<<endl;
    cout<<"The perimter of the rectangle is: "<<2*(width+height)<<endl; 
}

int main()
{
    Rectangle obj;
    obj.displaytheareaandperimeter();
    return 0;
}
