#include <iostream>
#include <cmath>
using namespace std;
class Shape {
public:
    virtual double calculateArea()=0;
    virtual double calculatePerimeter()=0;
};

class Rectangle : public Shape {
private:
    double length;
    double width;
public:
    Rectangle(double l, double w){
        length=l;
        width=w;
    }

    double calculateArea() {
        return length * width;
    }

    double calculatePerimeter() {
        return 2 * (length + width);
    }
};

class Circle : public Shape {
private:
    double radius;
public:
    Circle(double r){
        radius=r;
    }
    double calculateArea() {
        return M_PI * radius * radius;
    }

    double calculatePerimeter()  {
        return 2 * M_PI * radius;
    }
};

class Triangle : public Shape {
private:
    double side1, side2, side3;
public:
    Triangle(double s1, double s2, double s3){
         side1=s1;
         side2=s2;
         side3=s3;
    }
    double calculateArea() {
        double s = (side1 + side2 + side3) / 2;
        return sqrt(s * (s - side1) * (s - side2) * (s - side3));
    }

    double calculatePerimeter()  {
        return side1 + side2 + side3;
    }
};

int main() {
    Rectangle rectangle(5, 4);
    Circle circle(3);
    Triangle triangle(3, 4, 5);
   cout << "Rectangle:" <<endl;
   cout << "Area: " << rectangle.calculateArea() <<endl;
   cout << "Perimeter: " << rectangle.calculatePerimeter() <<endl;
   cout << "\nCircle:" <<endl;
   cout << "Area: " << circle.calculateArea() <<endl;
   cout << "Perimeter: " << circle.calculatePerimeter() <<endl;  
   cout << "\nTriangle:" <<endl;
   cout <<   "Area: " << triangle.calculateArea() <<endl;
   cout << "Perimeter: " << triangle.calculatePerimeter() <<endl;
    return 0;
}
