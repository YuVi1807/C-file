#include<iostream>
#include<string> 

using namespace std;

class Employee
{
private:
    int id;
    double salary; 
    string name;

public: 
    void setID(int empID) {
        id = empID;
    }

    int getID() const {
        return id;
    }

    void setName(const string& empName) {
        name = empName;
    }

    string getName() const {
        return name;
    }

    void setSalary(double empSalary) {
        salary = empSalary;
    }

    string getFormattedSalary() const {
        return "Rupees " + to_string(salary);
    }

    void get();
    void display() const;
};

    void Employee::get() {
        cout << "Enter Employee ID : ";
        cin >> id;
        cout << "Enter Employee Salary : ";
        cin >> salary;
        cout << "Enter Employee Name : ";
        cin >> name;
    }

      void Employee::display() const {
        cout << endl << "Employee ID : " << id;
        cout << endl << "Employee Salary : " << getFormattedSalary();
        cout << endl << "Employee Name : " << name;
    }

int main()
{
    Employee obj;
    obj.get();
    obj.display();

    return 0;
}
