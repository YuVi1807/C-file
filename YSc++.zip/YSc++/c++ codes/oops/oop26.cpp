#include<iostream>
#include<conio.h>

using namespace std;

class BankAccount
{
private:
   long accountNumber;
   double balance;
public:
    BankAccount(long a, double b){
        accountNumber=a;
        balance=b;
    }

    long getacc(){
        return accountNumber;
    }

    double getbal(){
        return balance;
    }

    void setacc(long a){
        accountNumber=a;
    }

    void setbal(double b){
        balance=b;
    }
   
};

int main()
{
    BankAccount obj(987654321, 5000);
    cout<<"Initial Account Details: "<<endl;
    cout<<"Account Number is: "<<obj.getacc()<<endl;
    cout<<"Balance is: "<<obj.getbal()<<endl;

    obj.setbal(10000);

    cout<<"\nUpdates Account Details: "<<endl;
    cout<<"Account Number is: "<<obj.getacc()<<endl;
    cout<<"Balance is: "<<obj.getbal()<<endl;    
    return 0;
}
