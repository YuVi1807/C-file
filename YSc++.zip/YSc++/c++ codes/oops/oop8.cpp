#include<iostream>
#include<conio.h>
#include<string.h>

using namespace std;

class TrafficLight
{
private:
   char color[10];
   int duration;
public:
    TrafficLight(char c[], int d){
        strcpy(color,c);
        duration=d;
    }
    
    void changecolor(char newcolor[]){
        strcpy(color,newcolor);
    }
    
    void display1();
    void display2();
};

void TrafficLight::display1(){
        cout<<"Traffic Light changed to "<<color<<" color."<<endl;
    }
    
void TrafficLight::display2(){
    cout<<"Color is: "<<color<<" and Duration is: "<<duration<<endl;
}
int main()
{
    TrafficLight obj("Red", 60);
    obj.display2();

    obj.changecolor("Green");
    
    obj.display1();
    obj.display2();
    return 0;
}
