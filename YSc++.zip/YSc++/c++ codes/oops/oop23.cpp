#include<iostream>
#include<conio.h>

using namespace std;

int i=1;

class student
{
private:
   int rollno;
   char name[20];
   char clas[10];
public:
   void get(){
    cout<<"Enter your Name: ";
    cin>>name;
    cout<<"Enter your Class: ";
    cin>>clas;
    rollno=i;
    i++;
    }
   void display(){
    get();
    cout<<"Your Name is: "<<name<<endl;
    cout<<"Your Class is: "<<clas<<endl;
    cout<<"Your RollNo. is: "<<rollno<<endl;
   }
};   

int main()
{
    student obj;
    for(int i=1; i<=10; i++){
        obj.display();
    }
    return 0;
}
