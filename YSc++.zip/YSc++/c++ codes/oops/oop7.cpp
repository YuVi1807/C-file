#include<iostream>

using namespace std;

class Account
{
	char name[20];
	int age;
	public:
		void getd();
		void display();
};

void Account::getd()
		{
			cout<<"Enter Name : ";
			cin>>name;
			cout<<"Enter Age : ";
			cin>>age;
		}
void Account::display()
		{
			cout<<endl<<"Name : "<<name;
			cout<<endl<<"Age : "<<age;
		}

class Bank
{
	int balance;
	int change;
	Account a1;
	public :
		Bank()
		{
			a1.getd();
			balance=10000;
		}
		void withdraw();
		void deposit();
		void current();
};

        void Bank::withdraw()
		{
			a1.display();
			cout<<endl<<"Enter Amount to withdraw : ";
			cin>>change;
			if(change>balance)
			{
				cout<<endl<<"Insufficient Balance!";
				cout<<endl<<"Current balance : "<<balance;
			}
			else
			{
				balance=balance-change;
				cout<<endl<<"Amount Withdrawed Succesfully!";
				cout<<endl<<"Current Balance : "<<balance;
			}
		}

        void Bank::deposit()
		{
			a1.display();
			cout<<endl<<"Enter Amount to Deposit : ";
			cin>>change;
			balance=balance+change;
			cout<<endl<<"Amount Deposited Successfully!";
			cout<<endl<<"Current Balance : "<<balance;
		}

        void Bank::current()
		{
			a1.display();
			cout<<endl<<"Current Balance : "<<balance;
		}

int main()
{
	Bank b1;
	int ch;
	cout<<"Menu: ";
	cout<<endl<<"1. Deposit";
	cout<<endl<<"2. Withdraw";
	cout<<endl<<"3. Current Balance";
	cout<<endl<<"4. Exit";
	cout<<endl<<"Enter your choice : ";
	cin>>ch;
	switch(ch)
	{
		case 1:
			b1.deposit();
			break;
		case 2:
			b1.withdraw();
			break;
		case 3:
			b1.current();
			break;
		case 4:
			cout<<"Goodbye";
			break;
		default :
			cout<<"Invalid choice";
	}
}