#include<iostream>
#include<conio.h>

using namespace std;

class Student
{
private:
    int student_id;
    char student_name[20];
    char grades ;
public:
    void get();
    void set();
    void add();

};

void Student::get(){
    cout<<"Enter your Student id  : "<<endl;
    cin>> student_id;
    cout<<"Enter your name : "<<endl;
    cin>>student_name;
}

void Student::set(){
 cout<<"The student ID is : "<<student_id<<endl;
 cout<<"The name of the student is : "<<student_name<<endl;
}

void Student::add(){
    cout<<"Enter your grades "<<endl;
    cin>>grades;
}

int main(){
    Student obj;
    obj.get();
    obj.set();
    obj.add();
return 0;
}

