#include<iostream>
#include<conio.h>
#include<string.h>

using namespace std;

class Employee
{
private:
    char name[20];
    char jobtitle[20];
    double salary;
public:
   Employee(char n[], char t[], double s){
        strcpy(name,n);
        strcpy(jobtitle,t);
        salary=s;
   }
   
   void setter(double newsalary){
        salary= newsalary;
   }
  
   void display();
   };

void Employee:: display(){
    cout<<"Name: "<<name<<endl;
    cout<<"Job Title: "<<jobtitle<<endl;
    cout<<"Salary: "<<salary<<endl;
   }

int main()
{
    Employee obj("Ankit","Web Developer", 70000);

    cout<<"Employee Details: "<<endl;
    obj.display();

    obj.setter(80000);

    cout<<"\nUpdated Employee Details: "<<endl;
    obj.display();
    return 0;
}
