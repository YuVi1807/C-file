#include<iostream>
#include<conio.h>

using namespace std;

class area
{
private:
    int radius, length, width;
    float pi=3.14;
public:
   void calculatearea(float r){
    radius=r;
    cout<<"The area of circle is: "<<pi*radius*radius<<endl;
   }

   void calculatearea(int l, int w){
    length=l;
    width=w;
    cout<<"The area of recatangle is: "<<length*width<<endl;    
   }
};

int main()
{
    area obj;
    obj.calculatearea(5);
    obj.calculatearea(4,5);
    return 0;
}
