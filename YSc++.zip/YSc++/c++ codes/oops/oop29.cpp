#include<iostream>

using namespace std;

class Circle
{
	int radius;
	float perimeter;
	float area;
	public :
		void get();
		void display();
		float CalculatePerimeter();
		float CalculateArea();
};

	void Circle::get(){
			cout<<"Enter Radius of Circle : ";
			cin>>radius;
		}

	void Circle::display(){
			cout<<endl<<"Radius of Circle is: "<<radius;
		}

	float Circle::CalculatePerimeter(){
			perimeter=2*3.14*radius;
			return perimeter;
		}

	float Circle::CalculateArea(){
			area=3.14*radius*radius;
			return area;
		}

int main()
{
	Circle obj;
	float a,b;
	obj.get();
	obj.display();
	a=obj.CalculateArea();
	b=obj.CalculatePerimeter();
	cout<<endl<<"Area of Circle is: "<<a;
	cout<<endl<<"Perimeter of Circle is: "<<b;
}
