#include<iostream>
#include<conio.h>

using namespace std;

class A
{
private:
   int x;
public:
    A(){
        x=10;
    }
   void display(){
    cout<<"The value of x is: "<<x<<endl;
   }
};

int main()
{
    A obj;
    obj.display();
    return 0;
}
