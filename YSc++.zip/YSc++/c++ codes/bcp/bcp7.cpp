#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int n,a;
    long x=0,y=1;
    cout<<"Enter any Number : ";
    cin>>n;

    a=n;

    while(n>0){
    x=x+(n%2)*y;
    n=n/2;
    y=y*10;
    }

    cout<<"Binary value of "<<a<<" is: "<<x;
    return 0;
}