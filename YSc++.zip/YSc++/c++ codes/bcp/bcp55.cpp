#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int a,b,c,d,e;
cout<<"Enter first value: "<<endl;
cin>>a;
cout<<"Enter second value: "<<endl;
cin>>b;
cout<<"Enter third value: "<<endl;
cin>>c;
cout<<"Enter fourth value: "<<endl;
cin>>d;
cout<<"Enter fifth value: "<<endl;
cin>>e;

cout<<"The Sum of these value is: "<<a+b+c+d+e<<endl;
cout<<"The Average of these value is: "<<(a+b+c+d+e)/5<<endl;    
    
    return 0;
}