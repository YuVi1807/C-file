#include<iostream>
#include<conio.h>
#include<string.h>

using namespace std;

int main()
{
	char str[50];
	cout<<"Enter String: "<<endl;
	cin>>str;

	cout<<"The length of the string is: "<<strlen(str)<<endl;   
    
    return 0;
}