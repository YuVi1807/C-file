#include<iostream>
using namespace std;
int main()
{
int n,num,g,s;
cout<<"Enter how many times you want to input integers: ";
cin>>n;
cout<<"Enter integers : ";
cin>>num;
g=num;
s=num;
for(int i=0;i<n-1;i++){
    cin>>num;
    if(g<num){
       g=num;
    }
    if(s>num){
        s=num;
    }
}
cout<<"Largest Number : "<<g<<endl;
cout<<"Smallest Number : "<<s<<endl;
return 0;
}