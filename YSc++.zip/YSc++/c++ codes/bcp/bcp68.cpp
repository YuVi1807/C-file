#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;

int main()
{
    string str;
    cout<<"Enter string: ";
    cin>>str;
    
    for(int i=0;i<str.length();i++){
    if(str[i]>=65 && str[i]<=90){
    str[i]=str[i]+32;
    }
}
    cout<<"Lower Case of string is: "<<str<<endl;   
    return 0;
}
