#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
float a,b,c,d,e,f;
cout<<"Enter the Percentage of 1st semester: "<<endl;
cin>>a;
cout<<"Enter the Percentage of 2nd semester: "<<endl;
cin>>b;
cout<<"Enter the Percentage of 3rd semester: "<<endl;
cin>>c;
cout<<"Enter the Percentage of 4th semester: "<<endl;
cin>>d;
cout<<"Enter the Percentage of 5th semester: "<<endl;
cin>>e;
cout<<"Enter the Percentage of 6th semester: "<<endl;
cin>>f;

cout<<"The CGPA of student is: "<<((a+b+c+d+e+f)/6)/9.5<<endl;    
     return 0;
}