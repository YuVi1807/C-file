#include<iostream>
#include<cmath>

using namespace std;

int main()
{
float f;
cout<<"Enter the float value : ";
cin>>f;
cout<<"Rounded float value : "<<round(f);
return 0;
}