#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int n,r,a,sum=0;
    cout<<"Enter any number: "<<endl;
    cin>>n;
    a=n;
    while (n>0)
    {
        r=n%10;
        sum=r+(sum*10);
        n=n/10;
    }
    if (a==sum)
    {
      cout<<a<<" is a Palindrome number"<<endl;
    }
    else
    {
        cout<<a<<" is not a Palindrome number"<<endl;
    }
    
    return 0;
}