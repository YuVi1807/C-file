#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int perimeter, apothem;
	cout<<"Enter Perimeter: "<<endl;
	cin>>perimeter;
	cout<<"Enter Apothem: "<<endl;
	cin>>apothem;

cout<<"The Area of Pentagon is: "<<0.5*perimeter*apothem<<endl;    
    
    return 0;
}