/*To check this you have to execute this program in your computer's command prompt
(1)change directory to where this file is located using cd
(2)type g++ file_name.cpp -o exe_filename
(3)type exe_filename.exe
If the output displays on the screen it means the C++ is installed in your computer */
#include<iostream>
using namespace std;
int main()
{
cout<<"Hello World";
return 0;
}