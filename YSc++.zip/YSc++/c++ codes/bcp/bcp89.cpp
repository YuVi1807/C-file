#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int c,a,z=0, n=0, p=0;
    cout<<"Enter how many integers you want: "<<endl;
    cin>>c;
    cout<<"Enter Number: "<<endl;
    for(int i=1;i<=c; i++){
    cin>>a;

    if(a>0){
        p+=1;
    }
    else if(a<0){
        n+=1;
    } 
    else
    z+=1;
    }
    cout<<"You Enter "<<p<<" positive numbers"<<endl;
    cout<<"You Enter "<<n<<" negative numbers"<<endl;
    cout<<"You Enter "<<z<<" zeroes"<<endl;
    return 0;
}