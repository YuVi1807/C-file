#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int sales, prod=25;
float commission;
cout<<"Enter Sales: "<<endl;
cin>>sales;

if(sales>0 && sales<=20)
{
commission=prod*0.10*sales;
}
else if(sales>20 && sales<=40)
{
commission=prod*0.18*sales;
}
else if(sales>40 && sales<=60)
{
commission=prod*0.25*sales;
}
else if(sales>60 && sales<=80)
{
commission=prod*0.32*sales;
}
else if(sales>80 && sales<=100)
{
commission=prod*0.37*sales;
}
else
commission=prod*0.44*sales;

cout<<"The Commission for sales of "<<sales<<" products is: "<<commission<<endl;    
    
    return 0;
}