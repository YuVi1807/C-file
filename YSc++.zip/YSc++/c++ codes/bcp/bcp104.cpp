#include<iostream>
#include<conio.h>
using namespace std;

int main()
{ 
    cout<<"Prime numbers between 1 to 20 are: "<<endl;
    int i,j;
      for(i=2; i<=20;i++){
        for(j=2;j<=i/2;j++){
            if(i%j==0)
            break;
        }
        if (j>i/2)
        {
            cout<<i<<endl;
        }
        
      }
    
    return 0;
}