#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int a,b;
cout<<"Enter the first number: "<<endl;
cin>>a;
cout<<"Enter the second number: "<<endl;
cin>>b;

for(int i=0; i<b; i++){
a++;
}

cout<<"Sum of two number is: "<<a;       
    return 0;
}