#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
 int base,height,perimeter;
cout<<"Enter Base: "<<endl;
cin>>base;
cout<<"Enter Perimeter: "<<endl;
cin>>perimeter;
cout<<"Enter Height: "<<endl;
cin>>height;
cout<<"The area of Prism is: "<<2*base+perimeter*height<<endl;   
     return 0;
}