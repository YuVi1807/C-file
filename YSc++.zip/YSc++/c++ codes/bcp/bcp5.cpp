#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int a,b,c,d,e;
cout<<"Enter the first value: "<<endl;
cin>>a;
cout<<"Enter the second value: "<<endl;
cin>>b;
cout<<"Enter the third value: "<<endl;
cin>>c;
cout<<"Enter the fourth value: "<<endl;
cin>>d;
cout<<"Enter the fifth value: "<<endl;
cin>>e;
cout<<"The Average of five numbers is: "<<(a+b+c+d+e)/5<<endl;
return 0;
}