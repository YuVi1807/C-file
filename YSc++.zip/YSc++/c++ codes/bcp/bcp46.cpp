#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
char name[30];
int runs,out;

cout<<"Enter the Cricketer Name: "<<endl;
cin>>name;
cout<<"Enter the total numbers of runs they have scored: "<<endl;
cin>>runs;
cout<<"Enter the number of times they have been out: "<<endl;
cin>>out;

cout<<"The Batting average of "<<name<<" is: "<<runs/out<<endl;   
    return 0;
}