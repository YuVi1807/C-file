#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int height,breadth;

	cout<<"Enter Breadth: "<<endl;
	cin>>breadth;
	cout<<"Enter Height: "<<endl;
	cin>>height;
    cout<<"The  Area of Triangle is: "<<0.5*breadth*height<<endl;    
    
    return 0;
}