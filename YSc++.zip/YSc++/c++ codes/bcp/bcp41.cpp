#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int n, sum=0;
cout<<"Enter number: "<<endl;
cin>>n;
for(int i=1; i<=n; i++)
{
sum+=i;
}
cout<<"The sum of n number is: "<<sum<<endl;     
    return 0;
}