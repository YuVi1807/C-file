#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int a,b,c;
cout<<"Enter First Number: "<<endl;
cin>>a;
cout<<"Enter Second Number: "<<endl;
cin>>b;
cout<<"Enter Third Number: "<<endl;
cin>>c;

if(a>b && a>c)
{
cout<<"The Greatest Number Among Three Numbers is: "<<a<<endl;
}
else if(b>a && b>c)
{
cout<<"The Greatest Number Among Three Numbers is: "<<b<<endl;
}
else
{
cout<<"The Greatest Number Among Three Numbers is: "<<c<<endl;
}    
    
    return 0;
}