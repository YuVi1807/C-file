#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int edge;
cout<<"Enter Edge: "<<endl;
cin>>edge;
cout<<"The surface area of cube is: "<<6*edge*edge<<endl;   
     return 0;
}