#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;

int main()
{
   string str;
    cout<<"Enter String: "<<endl;
    cin>>str;
    
    for(int i=0; i<str.length(); i++){
        if(str[i]=='d'){
         str[i]='f';
        }
    }
    cout<<"Your Replacing String from D to F is: "<<str<<endl;
    return 0;
}