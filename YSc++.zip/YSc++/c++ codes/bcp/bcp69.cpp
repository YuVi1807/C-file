#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;

int main()
{
    string str;
    cout<<"Enter string: ";
    cin>>str;
    
    for(int i=0;i<str.length();i++){
    if(str[i]>=97 && str[i]<=122){
    str[i]=str[i]-32;
    }
}
    cout<<"Upper Case of string is: "<<str<<endl;   
    return 0;
}
