#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int n, sum1=0, sum2=0, i;
    cout<<"Enter How Many integers you want to add: "<<endl;
    cin>>n;
    for(i=1; i<=n; i++){
    cout<<"Enter integer: "<<endl;
    cin>>i;
    
    
    if(i%2!=0)
    {
        sum1=sum1+i;
    }
     else if(i%2==0)
    {
        sum2=sum2+i;
    }
    }
    cout<<"The sum of odd integer is: "<<sum1<<endl;
    
    cout<<"The sum of even integer is: "<<sum2<<endl;
    return 0;
}