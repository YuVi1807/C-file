#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;

int main()
{
    char str[20];
	int x,i=0;

	cout<<"Enter a string : ";
	cin>>str;

	int l=strlen(str);

	cout<<"Enter index to find character : ";
	cin>>x;

	int f=x-1;

	if(x<l)
	{
		while(str[i]!='\0')
		{
			if(i==f)
			{
				cout<<endl<<"Character at index "<<x<<" : "<<str[i];
				break;
			}
			i++;
		}
	}
	else
	{
		cout<<endl<<"Invalid Index";
	}
    return 0;
        
}