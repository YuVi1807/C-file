#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    float n;
    cout<<"Enter the float value : ";
    cin>>n;

    if(n>=0){
        cout<<"Absolute value : "<<n;
    }
    else{
        cout<<"Absolute value : "<<-n;
    }  
    
    return 0;
}