#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int n,nn,nnn;
cout<<"Enter n: ";
cin>>n;
cout<<"The value of n is: "<<n+n*n+n*n*n<<endl;
return 0;
}