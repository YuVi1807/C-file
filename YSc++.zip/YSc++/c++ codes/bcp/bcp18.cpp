#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    string str;
    int n=0,p=10;
    cout<<"Enter the integers for string : ";
    cin>>str;
    for(int i=0;i<str.length();i++){
       n=p*n+(str[i]-'0');
       cout<<p<<endl;
   }

   cout<<n;
    return 0;
}