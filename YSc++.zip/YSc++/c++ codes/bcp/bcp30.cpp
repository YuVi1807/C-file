#include<iostream>

using namespace std;

int main()
{
int base,height;
cout<<"Enter Base: "<<endl;
cin>>base;
cout<<"Enter Height: "<<endl;
cin>>height;
cout<<"The area of Parallelogram is: "<<base*height<<endl;
    return 0;
}
