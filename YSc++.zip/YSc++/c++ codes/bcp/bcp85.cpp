#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int n, r;
    cout<<"Enter any number: "<<endl;
    cin>>n;
    cout<<"Number in reverse order: "<<endl;
    while (n>0)
    {
        r=n%10;
        cout<<r;
        n=n/10;
    }
    
    
    return 0;
}