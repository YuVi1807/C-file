#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
char name[30];
int marks, roll_no;
cout<<"Enter Name of the student: "<<endl;
cin>>name;
cout<<"Enter Roll No. of the student: "<<endl;
cin>>roll_no;
cout<<"Enter Marks of the student: "<<endl;
cin>>marks;

if(marks>=81 && marks<=100)
{
cout<<"A Grade"<<endl;
}
else if(marks>=61 && marks<=80)
{
cout<<"B Grade"<<endl;
}
else if(marks>=41 && marks<=60)
{
cout<<"C Grade"<<endl;
}
else if(marks>=0 && marks<=40)
{
cout<<"D Grade"<<endl;
}
else
{
cout<<"Wrong Marks"<<endl;
}   
    
    return 0;
}