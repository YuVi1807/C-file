#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int a,b;
cout<<"Enter the first value: "<<endl;
cin>>a;
cout<<"Enter the second value: "<<endl;
cin>>b;
cout<<"The sum of first and second value is: "<<a+b<<endl;
return 0;
}