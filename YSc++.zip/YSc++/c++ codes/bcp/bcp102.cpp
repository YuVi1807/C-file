#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int n;
	cout<<"Enter number: "<<endl;
	cin>>n;

	if(n%2==0)
	cout<<n<<" is a even number"<<endl;
	else
	cout<<n<<" is not a even number"<<endl;   
    
    return 0;
}