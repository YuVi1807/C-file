#include<iostream>
#include<cctype>

using namespace std;

int main()
{
char ch;
cout<<"Enter the character : ";
cin>>ch;

if (isalpha(ch)){
    if(ch=='a'||ch=='A'||ch=='e'||ch=='E'||ch=='i'||ch=='I'||ch=='o'||ch=='O'||ch=='u'||ch=='U'){
       cout<<"It is a vowel";}
    else{
        cout<<"It is a consonant ";
    }
}
else{
    cout<<"It is not an alphabet ";
}
return 0;
}