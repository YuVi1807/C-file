#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
int n;
cout<<"Enter the number : ";
cin>>n;

int r=0, remainder;
while(n!=0){
    remainder=n%10;
    r=r*10+remainder;
    n/=10;
}
cout<<"Reverse of integer : "<<r;    
    return 0;
}