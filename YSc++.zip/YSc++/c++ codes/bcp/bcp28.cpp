#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
 int side;
cout<<"Enter Side: "<<endl;
cin>>side;
cout<<"The area of Equilateral Triangle is: "<<0.43*side*side<<endl;   
     return 0;
}