#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int a,b;
    cout<<"Enter two numbers: ";
    cin>>a>>b;
    while (a != b)
    {
       if(a>b){
        a=a-b;
       }
       else{
        b=b-a;
       }
    }
    cout<<"HCF of two numbers is: "<<a;
    
    return 0;
}