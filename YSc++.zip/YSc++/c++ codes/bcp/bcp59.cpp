#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int n, sum=0;
cout<<"Enter number: "<<endl;
cin>>n;
if(n%2!=0)
{ cout<<"The n terms of odd natural numbers is: "<<endl;
 for(int i=1; i<=n; i++){
 cout<<i<<endl;
  sum=sum+i;
 }
}
 cout<<"The sum of n terms of odd natural numbers is: "<<sum<<endl;   
    
    return 0;
}