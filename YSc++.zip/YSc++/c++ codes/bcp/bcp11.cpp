#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int a,b;
cout<<"Enter a: "<<endl;
cin>>a;
cout<<"Enter b: "<<endl;
cin>>b;

if(a==b)
{
cout<<"a and b are same"<<endl;
}
else
{
cout<<"a and b are not same"<<endl;
}  
    return 0;
}