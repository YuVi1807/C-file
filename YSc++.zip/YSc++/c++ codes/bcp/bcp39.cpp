#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int n, sum=0, a[30];
cout<<"Enter the number of subjects: "<<endl;
cin>>n;
for(int i=1; i<=n;i++)
{
cout<<"Enter the marks of subject: "<<endl;
cin>>a[i];
sum+=(a[i])/n;
}
cout<<"The average of subject is: "<<sum<<endl;
     return 0;
}




