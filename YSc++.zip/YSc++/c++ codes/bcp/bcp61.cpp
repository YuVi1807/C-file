#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int n;
cout<<"Enter Number: "<<endl;
cin>>n;

if(n==0)
{
cout<<"It is Zero"<<endl;
}
else if(n>0)
{
cout<<"It is a Poistive Integer"<<endl;
}
else if(n<0)
{
cout<<"It is Negative Integer"<<endl;
}
else
cout<<"It is not a integer"<<endl;    
    
    return 0;
}