#include<iostream>

using namespace std;

class Complex
{
	int num1,num2;
	public :
		void get()
		{
			cout<<"Enter first complex number : " <<endl;
			cin>>num1;
            cout<<"Enter Second complex number : "<<endl;
            cin>>num2;
		}
                Complex operator+( Complex x){
                           
                            Complex y;
                            y.num1=num1+x.num1;
                            y.num2=num2+x.num2;
                            return y;
                }
		void display()
		{
			cout<<"Addition of complex number : "<<num1<<" + "<<num2;
		}
};

int main()
{
	Complex obj1,obj2,result;
	obj1.get();
	obj2.get();
	result=obj1+obj2;
	result.display();
    return 0;
}