#include <iostream>

using namespace std;

class Shape2D {
public:
    virtual void draw() const = 0;
    virtual void resize(double factor) = 0;
};

class Rectangle : public Shape2D {
private:
    double length;
    double width;
public:
    Rectangle(double l, double w) : length(l), width(w) {}
    void draw() const override {
        cout << "Drawing Rectangle with length " << length << " and width " << width << std::endl;
    }
    void resize(double factor) override {
        length *= factor;
        width *= factor;
        cout << "Resized Rectangle to length " << length << " and width " << width << std::endl;
    }
};

class Circle : public Shape2D {
private:
    double radius;
public:
    Circle(double r) : radius(r) {}
    void draw() const override {
        cout << "Drawing Circle with radius " << radius << std::endl;
    }
    void resize(double factor) override {
        radius *= factor;
        cout << "Resized Circle to radius " << radius << std::endl;
    }
};

int main() {
    Rectangle r(10, 17);
    Circle c(8);

    r.draw();
    r.resize(2);

    c.draw();
    c.resize(1.5);

    return 0;
}
