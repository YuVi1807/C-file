#include <iostream>
#include <string>
using namespace std;

class Employee {
protected:
    string name;
    int id;

public:
    Employee(string n, int i) : name(n), id(i) {}
    virtual void calculateSalary() = 0;
    virtual void displayInfo() = 0;
};

class Manager : public Employee {
private:
    double salary;

public:
    Manager(string n, int i, double s) : Employee(n, i), salary(s) {}

    void calculateSalary() override {
        salary = 10000 + (0.1 * salary);
    }

    void displayInfo() override {
        cout << "Manager Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Salary: " << salary << endl;
    }
};

class Programmer : public Employee {
private:
    double salary;

public:
    Programmer(string n, int i, double s) : Employee(n, i), salary(s) {}

    void calculateSalary() override {
        salary = 13000 + (0.05 * salary);
    }

    void displayInfo() override {
        cout << "Programmer Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Salary: " << salary << endl;
    }
};

int main() {
    Manager m("Ankit", 1010, 200000);
    m.calculateSalary();
    m.displayInfo();

    cout << endl;

    Programmer p("Ayush", 1020, 150000);
    p.calculateSalary();
    p.displayInfo();

    return 0;
}


