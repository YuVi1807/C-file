#include <iostream>

using namespace std;

class Instrument {
public:
    virtual void play() = 0;
    virtual void tune() = 0;
};

class Glockenspiel : public Instrument {
public:
    void play() override {
        cout << "Playing Glockenspiel\n";
    }

    void tune() override {
        cout << "Tuning Glockenspiel\n";
    }
};

class Violin : public Instrument {
public:
    void play() override {
        cout << "Playing Violin\n";
    }

    void tune() override {
        cout << "Tuning Violin\n";
    }
};

int main() {
    Glockenspiel g;
    Violin v;

    g.play();
    g.tune();

    v.play();
    v.tune();

    return 0;
}
