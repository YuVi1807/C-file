#include <iostream>

using namespace std;

class GeometricShape {
public:
    virtual float area() = 0;
    virtual float perimeter() = 0;
};

class Triangle : public GeometricShape {
private:
    float base, height, side1, side2, side3;

public:
    Triangle(float b, float h, float s1, float s2, float s3) : base(b), height(h), side1(s1), side2(s2), side3(s3) {}

    float area() override {
        return 0.5 * base * height;
    }

    float perimeter() override {
        return side1 + side2 + side3;
    }
};

class Square : public GeometricShape {
private:
    float side;

public:
    Square(float s) : side(s) {}

    float area() override {
        return side * side;
    }

    float perimeter() override {
        return 4 * side;
    }
};

int main() {
    Triangle t(1, 2, 3, 4, 5);
    Square s(8);

    cout << "Triangle: " << endl;
    cout << "Area: " << t.area() << endl;
    cout << "Perimeter: " << t.perimeter() << endl;

    cout << "\nSquare: " << endl;
    cout << "Area: " << s.area() << endl;
    cout << "Perimeter: " << s.perimeter() << endl;

    return 0;
}

