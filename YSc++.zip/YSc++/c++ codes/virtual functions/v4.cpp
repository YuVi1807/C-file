#include <iostream>

using namespace std;

class BankAccount {
protected:
    double balance;

public:
    BankAccount() : balance(0) {}

    void deposit(double amount)
	 {
	 	cout << "Enter Deposited amount : ";
	 	cin>>amount;
        balance += amount;
    }

    void withdraw() {
        double amount;
        cout << "Enter the amount to withdraw: ";
        cin >> amount;

        if (amount <= balance) {
            balance -= amount;
            cout << "Withdrawn: " << amount << endl;
        } else {
            cout << "Insufficient " << endl;
        }
    }

    double getBalance() const {
        return balance;
    }
};

class SavingsAccount : public BankAccount {
public:
    void withdraw() 
	 {
        if (balance < 100) {
            cout << "Withdrawal not allowed insufficient balance" << endl;
        } else {
            BankAccount::withdraw();
        }
    }
};

int main() {
    SavingsAccount s;
    s.deposit(0);
    s.withdraw();
    cout << "Current Balance: " << s.getBalance() << endl;
    s.withdraw();
    cout << "Current Balance: " << s.getBalance() << endl;
    return 0;
}


