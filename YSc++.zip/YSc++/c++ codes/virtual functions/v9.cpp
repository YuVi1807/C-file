#include <iostream>

using namespace std;

class Person {
public:
    virtual void eat() = 0;
    virtual void exercise() = 0;
};

class Athlete : public Person {
public:
    void eat() override {
        cout << "An athlete eats a balanced diet \n";
    }

    void exercise() override {
        cout << "An athlete exercises rigorously \n";
    }
};

class LazyPerson : public Person {
public:
    void eat() override {
        cout << "A lazy person eat junk food and snacks \n";
    }

    void exercise() override {
        cout << "A lazy person rarely exercises \n";
    }
};

int main() {
    Athlete a;
    LazyPerson l;

    cout << "Athlete's routine:\n";
    a.eat();
    a.exercise();

    cout << "\n";

    cout << "Lazy person's routine:\n";
    l.eat();
    l.exercise();

    return 0;
}


