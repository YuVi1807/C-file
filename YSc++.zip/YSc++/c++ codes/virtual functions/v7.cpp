#include <iostream>
#include <cmath>

using namespace std;

class Shape3D {
public:
    virtual double calculateVolume() = 0;
    virtual double calculateSurfaceArea() = 0;
};

class Sphere : public Shape3D {
private:
    double radius;

public:
    Sphere(double r) : radius(r) {}

    double calculateVolume() override {
        return (4.0 / 3.0) * M_PI * pow(radius, 3);
    }

    double calculateSurfaceArea() override {
        return 4 * M_PI * pow(radius, 2);
    }
};

class Cube : public Shape3D {
private:
    double sideLength;

public:
    Cube(double s) : sideLength(s) {}

    double calculateVolume() override {
        return pow(sideLength, 3);
    }

    double calculateSurfaceArea() override {
        return 6 * pow(sideLength, 2);
    }
};

int main() {
    double s, c;

    cout << "Enter the radius of the sphere: ";
    cin >> s;

    cout << "Enter the side length of the cube: ";
    cin >> c;

    Sphere sphere(s);
    Cube cube(c);

    cout << "Sphere Volume: " << sphere.calculateVolume() << endl;
    cout << "Sphere Surface Area: " << sphere.calculateSurfaceArea() << endl;
    cout << "Cube Volume: " << cube.calculateVolume() << endl;
    cout << "Cube Surface Area: " << cube.calculateSurfaceArea() << endl;

    return 0;
}


