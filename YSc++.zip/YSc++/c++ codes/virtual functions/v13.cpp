#include <iostream>

using namespace std;

class Bird {
public:
    virtual void fly() = 0;
    virtual void makeSound() = 0;
};

class Eagle : public Bird {
public:
    void fly() override {
        cout << "Eagle is soaring high in the sky.\n";
    }
    void makeSound() override {
        cout << "Eagle makes a screeching sound.\n";
    }
};

class Sparrow : public Bird {
public:
    void fly() override {
        cout << "Sparrow is fluttering around.\n";
    }
    void makeSound() override {
        cout << "Sparrow chirps happily.\n";
    }
};

int main() {
    Eagle e;
    Sparrow s;

    cout << "Eagle:\n";
    e.fly();
    e.makeSound();

    cout << "\nSparrow:\n";
    s.fly();
    s.makeSound();

    return 0;
}

