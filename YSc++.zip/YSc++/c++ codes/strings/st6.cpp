#include<iostream>
#include<conio.h>
#include<string.h>

using namespace std;

int main()
{
    string str="Hello";

    str+=" World";

    cout<<"The string after add characters is: "<<str;
    
    return 0;
}
