#include<iostream>
#include<conio.h>
using namespace std;

void smallestnumber(int a, int b, int c);

int main()
{
    int a,b,c;
    cout<<"Enter First Number: ";
    cin>>a;
    cout<<"Enter Second Number: ";
    cin>>b;
    cout<<"Enter Third Number: ";
    cin>>c;

    smallestnumber(a,b,c);
    return 0;
}

void smallestnumber(int a, int b, int c){
    if (a<b && a<c)
    {
       cout<<a<<" is smallest among three numbers"<<endl;
    }
    else if (b<a && b<c)
    {
        cout<<b<<" is smallest among three numbers"<<endl;
    }
    else
    cout<<c<<" is smallest among three numbers"<<endl;      
}