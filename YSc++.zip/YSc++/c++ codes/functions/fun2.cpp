#include<iostream>
#include<conio.h>
using namespace std;

void average(int a, int b, int c);

int main()
{
    int a,b,c;
    cout<<"Enter First Number: ";
    cin>>a;
    cout<<"Enter Second Number: ";
    cin>>b;
    cout<<"Enter Third Number: ";
    cin>>c;

    average(a,b,c);
    return 0;
}

void average(int a, int b, int c){
    cout<<"The average of three numbers is: "<<(a+b+c)/3<<endl;    
}