#include <iostream>
#include<conio.h>

using namespace std;

int main() {
    int m,n;
    cout<<"Enter the number of rows: ";
    cin>>m;
    cout<<"Enter the number of columns: ";
    cin>>n;

    int mat[m][n];

    cout << "Enter the elements of the matrix:" << endl;
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            cin >> mat[i][j];
        }
    }

    // Check if the matrix is an identity matrix
    int i=1;
    for (int row=0; row<m && i; ++row) {
        for (int col=0; col<n && i; ++col) {
            if ((row==col && mat[row][col]!=1) || (row!=col && mat[row][col]!=0)) {
                i=0;
            }
        }
    }

    // Output the result
    if (i)
        cout<<"The given matrix is an identity matrix."<<endl;
    else
        cout<<"The given matrix is not an identity matrix."<<endl;

    return 0;
}