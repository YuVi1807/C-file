#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
    int n,m;
    cout<<"Enter Rows for Matrix: ";
    cin>>n;
    cout<<"Enter Columns for Matrix: ";
    cin>>m;
    int mat[n][m];

    cout<<"Enter Elements for Matrix: "<<endl;
    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            cin>>mat[i][j];
        }
    }

    cout<<"Elements in Matrix Format: "<<endl;
    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            cout<<mat[i][j]<<'\t';
        }
        cout<<endl;
    }
    return 0;
}
