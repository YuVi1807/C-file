#include<iostream>
#include<conio.h>

using namespace std;

int main()
{    
    int m,n,p,q;

    //Input Dimensions for the First Matrix
    cout<<"Enter the number of Rows and Columns for First Matrix: ";
    cin>>m>>n;

    //Input Dimensions for the Second Matrix
    cout<<"Enter the number of Rows and Columns for Second Matrix: ";
    cin>>p>>q;

    if(n!=p){
        cout<<"Matrix Multiplication is not possible. Inner dimensions must match."<<endl;
        return 1;
    }
   
   //Initialize Matrices
    int mat1[m][n], mat2[p][q], result[m][q];
    
    //Input Dimensions for First Matrix
    cout<<"Enter Elements for First Matrix: "<<endl;
    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){
            cin>>mat1[i][j];
        }
    }

    //Input Dimensions for Second Matrix
     cout<<"Enter Elements for Second Matrix: "<<endl;
    for(int i=0; i<p; i++){
        for(int j=0; j<q; j++){
            cin>>mat2[i][j];
        }
    }

    //Performing Matrix Multiplication
    for(int i=0; i<m; i++){
        for(int j=0; j<q; j++){
           result[i][j]=0;
            for(int k=0; k<n; k++){
             result[i][j]+= mat1[i][k]*mat2[k][j];
             }
        }
    }

    //Display the result
    cout<<"Multiplication of First and Second Matrix is: "<<endl;
    for(int i=0; i<m; i++){
        for(int j=0; j<q; j++){
            cout<<result[i][j]<<'\t';
        }
    cout<<endl;
    }
    return 0;
}
