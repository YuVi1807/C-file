#include<iostream>
#include<conio.h>

using namespace std;

int main() {
    int m, n, s = 0;

    cout<<"Enter the number of rows and columns for Matrix: ";
    cin>>m>>n;

    int mat[10][10];

    cout<<"Enter the elements of the matrix: "<<endl;
    for(int i=0; i<m; i++) {
        for (int j=0; j<n; j++) {
            cin>>mat[i][j];
        }
    }

    for (int i=0; i<m; i++) {
        for (int j=0; j<n; j++) {
            if (mat[i][j]==0) {
                s++;
            }
        }
    }

    if (s>((m*n)/2)) {
        cout<<"Sparse Matrix";
    } else {
        cout<<"Not a Sparse Matrix";
    }

    return 0;
}