#include <iostream>
using namespace std;

int main() {
    int m, n;
    cout<<"Enter the number of rows: ";
    cin>>m;
    cout<<"Enter the number of columns: ";
    cin>>n;

    int mat[m][n];

    cout<<"Enter the elements of the matrix:"<<endl;
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            cin>>mat[i][j];
        }
    }

    // Transpose the matrix
    int t[n][m];
    for (int i=0; i<n; ++i) {
        for (int j=0; j<m; ++j) {
            t[i][j]=mat[j][i];
        }
    }

    // Display the transpose matrix
    cout<<"\nTranspose of the matrix:"<<endl;
    for (int i=0; i<n; ++i) {
        for (int j=0; j<m; ++j) {
            cout<<t[i][j]<<" ";
        }
        cout<<endl;
    }
    return 0;
}