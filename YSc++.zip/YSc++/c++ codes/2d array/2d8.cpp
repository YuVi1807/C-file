#include <iostream>
#include<conio.h>

using namespace std;

int main() 
{
    int m, n;
    cout<<"Enter the number of rows: ";
    cin>>m;
    cout<<"Enter the number of columns: ";
    cin>>n;

    int mat[m][n];

    cout << "Enter the elements of the matrix:" << endl;
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            cin>>mat[i][j];
        }
    }

    int even = 0, odd = 0;

    // Counting frequency of even and odd numbers
    for (int i=0; i<m; ++i) {
        for (int j=0; j<n; ++j) {
            if (mat[i][j]%2==0)
                even++;
            else
                odd++;
        }
    }
    cout<<"\nFrequency of even numbers: " <<even<<endl;
    cout<<"Frequency of odd numbers: " <<odd<<endl;

    return 0;
}