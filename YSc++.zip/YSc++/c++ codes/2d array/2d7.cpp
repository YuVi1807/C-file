#include <iostream>
using namespace std;

int main() {
     int m, n;
    cout<<"Enter the number of rows: ";
    cin>>m;
    cout<<"Enter the number of columns: ";
    cin>>n;

    int mat[m][n];

    cout<<"Enter the elements of the matrix:" << endl;
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
                cin>>mat[i][j];
        }
    }

    cout<<"\nThe upper triangular matrix is:"<<endl;
    for (int i=0; i<m; ++i) {
        for (int j=0; j<n; ++j) {
            if (j >=i) {
                cout<<mat[i][j]<<"\t";
            } else {
                cout<<"0\t";
            }
        }
        cout<<endl;
    }

    return 0;
}