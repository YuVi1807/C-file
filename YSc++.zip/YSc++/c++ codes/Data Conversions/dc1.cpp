#include<iostream>
#include<string>

using namespace std;

int main()
{
    string str;
    cout<<"Enter the integers for string : ";
    cin>>str;
    cout<<"String value after conversion into integer : "<<stoi(str);
    return 0;
 }
