#include<iostream>
#include<string.h>
#include<sstream>

using namespace std;

int main()
{   
    stringstream ssr;
    string str="";
    double a;
    cout<<"Enter the string which you want to convert it into double : ";
    cin>>str;
    ssr<<str;
    ssr>>a;
    cout<<"String after conversion into double : "<<a;
    return 0;
}

