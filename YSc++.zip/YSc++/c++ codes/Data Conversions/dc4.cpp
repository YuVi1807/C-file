#include<iostream>
#include<string.h>
using namespace std;
int main()
{
    long a;
    string str="";
    cout<<"Enter the integer you want to change it into string : ";
    cin>>a;
    str=to_string(a);
    cout<<"Integer after conversion to string : "<<str;
    return 0;
}

