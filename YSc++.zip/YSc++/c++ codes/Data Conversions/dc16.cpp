#include<iostream>

using namespace std;

int main()
{
    int a=0,b=1,c,temp;
    cout<<"Enter the Decimal number: ";
    cin>>c;
    while(c!=0){
        temp=c%8;
        a=a+(b*temp);
        c=c/8;
        b=b*10;
    }
    cout<<"Octal number after conversion is: "<<a;
    return 0;
 }

    
