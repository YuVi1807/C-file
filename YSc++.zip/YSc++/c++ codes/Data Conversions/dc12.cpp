#include<iostream>
using namespace std;
int main()
{
    int a,b=1,temp;
    long long c=0;
    cout<<"Enter the decimal number: ";
    cin>>a;
    while (a!=0){
       temp=a%2;
       c=c+(temp*b);
       b=b*10;
       a=a/2;
    }
    cout<<"Binary value of decimal number is: "<<c;
    return 0;
}
