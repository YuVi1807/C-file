#include<iostream>
#include<string.h>
#include<sstream>

using namespace std;

int main()
{
    int n;
    char ch;
    cout<<"Enter the integer character: ";
    cin>>ch;
    n=ch-'0';
    cout<<"Character after conversion into int : "<<n;
    return 0;
}
