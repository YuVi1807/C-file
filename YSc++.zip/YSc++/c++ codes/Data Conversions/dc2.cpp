#include<iostream>
#include<string>

using namespace std;

int main()
{
    int a;
    string str="";
    cout<<"Enter the integer which you want to change it into string : ";
    cin>>a;
    str=to_string(a);
    cout<<"Integer after conversion into string : "<<str;
   return 0;
}
