#include<iostream>
#include<string>
#include<sstream>
using namespace std;
int main()
{
    stringstream ssr;
    string str="";
    double a;
    cout<<"Enter the double which you want to convert it into string : ";
    cin>>a;
    ssr<<a;
    ssr>>str;
    cout<<"String after conversion into double : "<<str;
    return 0;
}

