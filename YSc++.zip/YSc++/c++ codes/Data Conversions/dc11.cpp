#include<iostream>

using namespace std;

int main()
{
    int a=0,b=1,temp;
    long long c;
    cout<<"Enter the number in binary form: ";
    cin>>c;
    while (c!=0){
       temp=c%10;
       a=a+(temp*b);
       b=b*2;
       c=c/10;
    }
    cout<<"Decimal value of binary number is: "<<a;
    return 0;
}
