#include<iostream>
#include<fstream>
#include<string>
#include<algorithm>

using namespace std;

int main(){
    ofstream f1;
    f1.open("File4");
    f1<<"this"<<endl<<"is"<<endl<<"for"<<endl<<"the"<<endl<<"alphabetical"<<endl<<"order"<<endl;
    f1.close();

    fstream f;
    string l[10],st;
    f.open("File4",ios::in);
    int i=0;
    while(!f.eof()){
    getline(f,st);
    l[i]=st;
    i++;
  }
  sort(l,l+i);
  cout<<"Lines sorted alphabetical of file : "<<endl;
  for(int j=0;j<i;j++){
    cout<<l[j]<<endl;
  }
  f.close();
  return 0;
}