#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main() {
    ifstream f1("File1");
    ofstream f2("File3");

    string findWord = "First";
    string replaceWord = "Sixth";
    string word;
    while (f1 >> word) {
        if (word == findWord)
            f2 << replaceWord << " ";
        else
            f2 << word << " ";
    }
    f1.close();
    f2.close();

    cout << "Word replaced.";

    return 0;
}


