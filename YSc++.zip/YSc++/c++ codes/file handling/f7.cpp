#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main() 
{
    ofstream file("File1", ios::app);
    string Data;
    cout << "Enter the data to append: ";
    getline(cin, Data);
    file <<endl<<Data << endl;
    file.close();
    cout << "Data appended." << endl;
    return 0;
}


