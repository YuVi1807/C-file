#include <iostream>
#include <fstream>

using namespace std;

int main() {
    ofstream f("File1");
    
    f<< "Hello"<<endl;
    f<<"This is the First Program of File Handling";
    f.close();
    cout << "file 1 created";
    return 0;
}



